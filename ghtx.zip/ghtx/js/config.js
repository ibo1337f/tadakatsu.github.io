/* 
  Конифг для твоего сайта
  Можешь менять данные
*/

let config = {

  // Задержка загрузки (1 секунда)
  preloaderDelay: 1,

  // Задержка появления видео (4.2 секунды)
  showDelay: 10.5, 

  // Заголовок
  title: 'Mercury',

  // Социальные сети
  social: {
    telegram: '@ghtxfsh',
    steam: 'gthxfsh',
    vk: 'ghtxfsh',
  },





  // Цвет иконки загрузки
  preloaderColor: '#FF0000',


  // Цвет кнопки play
  playButtonColor: '#FF0000',
  // Цвет тени кнопки play
  playButtonShadowColor: '#313036',


  // Цвет заголовка
  titleColor: '#FF0000',
  // Цвет тени загаловка
  titleShadowColor: '#313036',


  // Текст копирайта
  copyrightText: '1000-7 ?',
  // Цвет копирайта
  copyrightTextColor: '#FF0000',

  // Цвет иконок социальных сетей
  socialColor: '#FF0000',
  // Цвет тени иконок социальных сетей
  socialShadowColor: '#313036',
}