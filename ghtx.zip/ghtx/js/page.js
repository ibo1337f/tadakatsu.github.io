// var code = window.atob("cHJlY2lzaW9uIGhpZ2hwIGZsb2F0Owp1bmlmb3JtIGZsb2F0IHRpbWU7CnVuaWZvcm0gdmVjMiByZXNvbHV0aW9uOwp2b2lkIG1haW4gKCkKewogIGhpZ2hwIHZlYzMgcmVkR29kQ29sb3JfMjsKICBoaWdocCB2ZWMyIHVQb3NfMzsKICB2ZWMyIHRtcHZhcl80OwogIHRtcHZhcl80LnkgPSAwLjU7CiAgdG1wdmFyXzQueCA9ICgocmVzb2x1dGlvbi54IC8gcmVzb2x1dGlvbi55KSAvIDIuMCk7CiAgdVBvc18zID0gKChnbF9GcmFnQ29vcmQueHkgLyByZXNvbHV0aW9uLnkpIC0gdG1wdmFyXzQpOwogIHJlZEdvZENvbG9yXzIgPSB2ZWMzKDAuMCwgMC4wLCAwLjApOwogIGZvciAoZmxvYXQgaV8xID0gMS4wOyBpXzEgPCA1MC4wOyBpXzEgKz0gMS4wKSB7CiAgICB2ZWMyIHBvaW50XzU7CiAgICBmbG9hdCB0bXB2YXJfNjsKICAgIHRtcHZhcl82ID0gKCh0aW1lICogMC4xNSkgLSAoNS4wICogaV8xKSk7CiAgICB2ZWMyIHRtcHZhcl83OwogICAgdG1wdmFyXzcueCA9ICgwLjU1ICogc2luKHRtcHZhcl82KSk7CiAgICB0bXB2YXJfNy55ID0gKDAuNSAqIHNpbigodG1wdmFyXzYgKiAwLjAyKSkpOwogICAgdmVjMiB0bXB2YXJfODsKICAgIHRtcHZhcl84LnggPSAoMC41NSAqIGNvcygodG1wdmFyXzYgKiAwLjEpKSk7CiAgICB0bXB2YXJfOC55ID0gKDAuNSAqIHNpbigodG1wdmFyXzYgKiAxLjMpKSk7CiAgICBwb2ludF81ID0gKHRtcHZhcl83ICsgdG1wdmFyXzgpOwogICAgcG9pbnRfNSA9IChwb2ludF81IC8gKDIuMCAqIHNpbihpXzEpKSk7CiAgICBoaWdocCBmbG9hdCB0bXB2YXJfOTsKICAgIHRtcHZhcl85ID0gKCgwLjAwMSAvICgKICAgICAgKCh1UG9zXzMueCAtIHBvaW50XzUueCkgKiAodVBvc18zLnggLSBwb2ludF81LngpKQogICAgICsgCiAgICAgICgodVBvc18zLnkgLSBwb2ludF81LnkpICogKHVQb3NfMy55IC0gcG9pbnRfNS55KSkKICAgICkpIC8gaV8xKTsKICAgIGhpZ2hwIHZlYzMgdG1wdmFyXzEwOwogICAgdG1wdmFyXzEwLnggPSB0bXB2YXJfOTsKICAgIHRtcHZhcl8xMC55ID0gKHRtcHZhcl85IC8gNC4wKTsKICAgIHRtcHZhcl8xMC56ID0gdG1wdmFyXzk7CiAgICByZWRHb2RDb2xvcl8yID0gKHJlZEdvZENvbG9yXzIgKyB0bXB2YXJfMTApOwogIH07CiAgaGlnaHAgdmVjNCB0bXB2YXJfMTE7CiAgdG1wdmFyXzExLncgPSAxLjA7CiAgdG1wdmFyXzExLnh5eiA9IHBvdyAocmVkR29kQ29sb3JfMiwgdmVjMygwLjUsIDIuMSwgMS4xKSk7CiAgZ2xfRnJhZ0NvbG9yID0gdG1wdmFyXzExOwp9Cgo=");
var code = window.atob("cHJlY2lzaW9uIG1lZGl1bXAgZmxvYXQ7CnVuaWZvcm0gZmxvYXQgdGltZTsKdW5pZm9ybSB2ZWMyIHJlc29sdXRpb247CnZvaWQgbWFpbiAoKQp7CiAgaGlnaHAgdmVjMiBwXzE7CiAgcF8xLnggPSBnbF9GcmFnQ29vcmQueDsKICBoaWdocCB2ZWMyIHRtcHZhcl8yOwogIHRtcHZhcl8yID0gKChnbF9GcmFnQ29vcmQueHkgLyByZXNvbHV0aW9uKSAtIDAuNSk7CiAgcF8xLnkgPSAoZ2xfRnJhZ0Nvb3JkLnkgKyAoMTIwLjAgKiB0aW1lKSk7CiAgaGlnaHAgZmxvYXQgdG1wdmFyXzM7CiAgdG1wdmFyXzMgPSBmcmFjdCgoc2luKAogICAgZG90IChmbG9vcigocF8xIC8gOC4wKSksIHZlYzIoMTIuOTE4OTgsIDc4LjIzMykpCiAgKSAqIDQxNTUzOC41KSk7CiAgaGlnaHAgdmVjMiB0bXB2YXJfNDsKICB0bXB2YXJfNCA9ICgodmVjMihtb2QgKHBfMSwgOC4wKSkpIC0gNC4wKTsKICBoaWdocCBmbG9hdCB0bXB2YXJfNTsKICB0bXB2YXJfNSA9IGNsYW1wICgoKAogICAgc3FydChkb3QgKHRtcHZhcl8yLCB0bXB2YXJfMikpCiAgIC0gMC4xKSAvIDAuNyksIDAuMCwgMS4wKTsKICBoaWdocCB2ZWMyIHBfNjsKICBwXzYueCA9IGFicyh0bXB2YXJfNC54KTsKICBwXzYueSA9IGZsb29yKCh0bXB2YXJfNC55IC0gLTEwLjApKTsKICBoaWdocCBmbG9hdCB0bXB2YXJfNzsKICB0bXB2YXJfNyA9ICgwLjYgKiAodGltZSArICgwLjIgKiB0bXB2YXJfMykpKTsKICBoaWdocCBmbG9hdCB0bXB2YXJfODsKICB0bXB2YXJfOCA9IGZsb29yKCh0bXB2YXJfNyAvIDIuMCkpOwogIGhpZ2hwIHZlYzIgdG1wdmFyXzk7CiAgdG1wdmFyXzkueCA9IGZyYWN0KChzaW4oCiAgICAodG1wdmFyXzggKiAwLjEyMykKICApICogNDMwOTguNTUpKTsKICB0bXB2YXJfOS55ID0gZnJhY3QoKHNpbigKICAgICh0bXB2YXJfOCAqIDIuMzcxKQogICkgKiA0MzA5OC41NSkpOwogIGhpZ2hwIHZlYzIgeF8xMDsKICB4XzEwID0gKHRtcHZhcl8yIC0gKCgyLjAgKiB0bXB2YXJfOSkgLSAxLjApKTsKICBoaWdocCBmbG9hdCB0bXB2YXJfMTE7CiAgdG1wdmFyXzExID0gY2xhbXAgKCgoCiAgICBhYnMoKHNxcnQoZG90ICh4XzEwLCB4XzEwKSkgLSAoZmxvYXQobW9kICh0bXB2YXJfNywgMi4wKSkpKSkKICAgLSAwLjIpIC8gLTAuMiksIDAuMCwgMS4wKTsKICBoaWdocCBmbG9hdCB0bXB2YXJfMTI7CiAgdG1wdmFyXzEyID0gKCgtMC4zICogKHRtcHZhcl81ICogCiAgICAodG1wdmFyXzUgKiAoMy4wIC0gKDIuMCAqIHRtcHZhcl81KSkpCiAgKSkgKyAoKAogICAgZmxvYXQoKDIuMCA+PSBwXzYueCkpCiAgICogCiAgICBmbG9hdCgoZmxvb3IoKGZsb2F0KG1vZCAoCiAgICAgICgoODA5OTk5LjAgKiB0bXB2YXJfMykgLyBleHAyKGZsb29yKChwXzYueCAtIAogICAgICAgICgzLjAgKiBwXzYueSkKICAgICAgKSkpKQogICAgLCAyMDAuMCkpKSkgPj0gMS4wKSkKICApICogKAogICAgKDAuMDYgKyAoMC4zICogKHRtcHZhcl8xMSAqICh0bXB2YXJfMTEgKiAKICAgICAgKDMuMCAtICgyLjAgKiB0bXB2YXJfMTEpKQogICAgKSkpKQogICArIAogICAgbWF4ICgwLjAsICgwLjIgKiBzaW4oKAogICAgICAoMTAuMCAqIHRtcHZhcl8zKQogICAgICogdGltZSkpKSkKICApKSk7CiAgbWVkaXVtcCB2ZWM0IHRtcHZhcl8xMzsKICB0bXB2YXJfMTMudyA9IDEuMDsKICB0bXB2YXJfMTMueHl6ID0gKHZlYzMoMC4xLCAwLjMsIDAuNikgKyB0bXB2YXJfMTIpOwogIGdsX0ZyYWdDb2xvciA9IHRtcHZhcl8xMzsKfQoK");
var canvas, gl, buffer, currentProgram;

var parameters = {
        startTime: Date.now(),
        time: 0,
        mouseX: 0.5,
        mouseY: 0.5,
        screenWidth: 0,
        screenHeight: 0
    },
    surface = {
        centerX: 0,
        centerY: 0,
        width: 1,
        height: 1,
        isPanning: false,
        isZooming: false,
        lastX: 0,
        lastY: 0
    },
    frontTarget, backTarget, screenProgram, getWebGL;

if (!window.requestAnimationFrame) {
    window.requestAnimationFrame = (function() {
        return window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame ||
            window.oRequestAnimationFrame ||
            window.msRequestAnimationFrame ||
            function(callback, element) {
                window.setTimeout(callback, 1000 / 60);
            };
    })();
}

init();

if (gl) {
    animate();
}

function init() {
    if (!document.addEventListener) {
        document.location = "http://get.webgl.org/";
        return;
    }

    canvas = document.createElement("canvas");
    document.body.appendChild(canvas);

    try {
        gl = canvas.getContext("experimental-webgl", {
            preserveDrawingBuffer: true
        });
    } catch (error) {}

    if (!gl) {
        document.location = "http://get.webgl.org/";
    } else {
        // enable dFdx, dFdy, fwidth
        gl.getExtension("OES_standard_derivatives");

        // Create vertex buffer (2 triangles)

        buffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1.0, -1.0, 1.0, -1.0, -1.0, 1.0, 1.0, -1.0, 1.0, 1.0, -1.0, 1.0]), gl.STATIC_DRAW);

        // Create surface buffer (coordinates at screen corners)

        surface.buffer = gl.createBuffer();
    }

    on_window_resize();
    window.addEventListener("resize", on_window_resize, false);

    compile_screen_program();
    compile();
}

function on_window_resize(event) {
    canvas.width = window.innerWidth / 2;
    canvas.height = window.innerHeight / 2;

    canvas.style.width = window.innerWidth + "px";
    canvas.style.height = window.innerHeight + "px";

    parameters.screenWidth = canvas.width;
    parameters.screenHeight = canvas.height;

    compute_surface_corners();

    if (gl) {
        gl.viewport(0, 0, canvas.width, canvas.height);
        create_render_targets();
    }
}

function compute_surface_corners() {
    if (gl) {
        surface.width = surface.height * parameters.screenWidth / parameters.screenHeight;

        var halfWidth = surface.width * 0.5,
            halfHeight = surface.height * 0.5;

        gl.bindBuffer(gl.ARRAY_BUFFER, surface.buffer);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
            surface.centerX - halfWidth, surface.centerY - halfHeight,
            surface.centerX + halfWidth, surface.centerY - halfHeight,
            surface.centerX - halfWidth, surface.centerY + halfHeight,
            surface.centerX + halfWidth, surface.centerY - halfHeight,
            surface.centerX + halfWidth, surface.centerY + halfHeight,
            surface.centerX - halfWidth, surface.centerY + halfHeight
        ]), gl.STATIC_DRAW);
    }
}

function animate() {
    requestAnimationFrame(animate);
    render();
}

function render() {
    if (!currentProgram) return;

    parameters.time = Date.now() - parameters.startTime;

    // Set uniforms for custom shader

    gl.useProgram(currentProgram);

    gl.uniform1f(currentProgram.uniformsCache["time"], parameters.time / 1000);
    gl.uniform2f(currentProgram.uniformsCache["mouse"], parameters.mouseX, parameters.mouseY);
    gl.uniform2f(currentProgram.uniformsCache["resolution"], parameters.screenWidth, parameters.screenHeight);
    gl.uniform1i(currentProgram.uniformsCache["backbuffer"], 0);
    gl.uniform2f(currentProgram.uniformsCache["surfaceSize"], surface.width, surface.height);

    gl.bindBuffer(gl.ARRAY_BUFFER, surface.buffer);
    gl.vertexAttribPointer(surface.positionAttribute, 2, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.vertexAttribPointer(vertexPosition, 2, gl.FLOAT, false, 0, 0);

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, backTarget.texture);

    // Render custom shader to front buffer

    gl.bindFramebuffer(gl.FRAMEBUFFER, frontTarget.framebuffer);

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 6);

    // Set uniforms for screen shader

    gl.useProgram(screenProgram);

    gl.uniform2f(screenProgram.uniformsCache["resolution"], parameters.screenWidth, parameters.screenHeight);
    gl.uniform1i(screenProgram.uniformsCache["texture"], 1);

    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.vertexAttribPointer(screenVertexPosition, 2, gl.FLOAT, false, 0, 0);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, frontTarget.texture);

    // Render front buffer to screen

    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 6);

    // Swap buffers

    var tmp = frontTarget;
    frontTarget = backTarget;
    backTarget = tmp;
}

function compile() {
    if (!gl) {
        if (!getWebGL) {
            getWebGL = true;
            document.location = "http://get.webgl.org/";
        }
		
        return;
    }

    var program = gl.createProgram();
    var fragment = code;
    var vertex = document.getElementById("surface_vertex").textContent;

    var vs = create_shader(vertex, gl.VERTEX_SHADER);
    var fs = create_shader(fragment, gl.FRAGMENT_SHADER);

    if (vs == null || fs == null) return null;

    gl.attachShader(program, vs);
    gl.attachShader(program, fs);

    gl.deleteShader(vs);
    gl.deleteShader(fs);

    gl.linkProgram(program);

    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        var error = gl.getProgramInfoLog(program);
        console.error(error);

        return;
    }

    currentProgram = program;

    // Cache uniforms

    cacheUniformLocation(program, "time");
    cacheUniformLocation(program, "mouse");
    cacheUniformLocation(program, "resolution");
    cacheUniformLocation(program, "backbuffer");
    cacheUniformLocation(program, "surfaceSize");

    // Load program into GPU

    gl.useProgram(currentProgram);

    // Set up buffers

    surface.positionAttribute = gl.getAttribLocation(currentProgram, "surfacePosAttrib");
    gl.enableVertexAttribArray(surface.positionAttribute);

    vertexPosition = gl.getAttribLocation(currentProgram, "position");
    gl.enableVertexAttribArray(vertexPosition);
}

function compile_screen_program() {
    if (!gl) {
        return;
    }

    var program = gl.createProgram();
    var fragment = document.getElementById("fragment").textContent;
    var vertex = document.getElementById("vertex").textContent;

    var vs = create_shader(vertex, gl.VERTEX_SHADER);
    var fs = create_shader(fragment, gl.FRAGMENT_SHADER);

    gl.attachShader(program, vs);
    gl.attachShader(program, fs);

    gl.deleteShader(vs);
    gl.deleteShader(fs);

    gl.linkProgram(program);

    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
        console.error("VALIDATE_STATUS: " + gl.getProgramParameter(program, gl.VALIDATE_STATUS), "ERROR: " + gl.getError());
        return;
    }

    screenProgram = program;

    gl.useProgram(screenProgram);

    cacheUniformLocation(program, "resolution");
    cacheUniformLocation(program, "texture");

    screenVertexPosition = gl.getAttribLocation(screenProgram, "position");
    gl.enableVertexAttribArray(screenVertexPosition);

}

function cacheUniformLocation(program, label) {

    if (program.uniformsCache === undefined) {

        program.uniformsCache = {};

    }

    program.uniformsCache[label] = gl.getUniformLocation(program, label);

}

function create_target(width, height) {

    var target = {};

    target.framebuffer = gl.createFramebuffer();
    target.renderbuffer = gl.createRenderbuffer();
    target.texture = gl.createTexture();

    // set up framebuffer

    gl.bindTexture(gl.TEXTURE_2D, target.texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);

    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);

    gl.bindFramebuffer(gl.FRAMEBUFFER, target.framebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, target.texture, 0);

    // set up renderbuffer

    gl.bindRenderbuffer(gl.RENDERBUFFER, target.renderbuffer);

    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, width, height);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, target.renderbuffer);

    // clean up

    gl.bindTexture(gl.TEXTURE_2D, null);
    gl.bindRenderbuffer(gl.RENDERBUFFER, null);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    return target;

}

function create_render_targets() {
    frontTarget = create_target(parameters.screenWidth, parameters.screenHeight);
    backTarget = create_target(parameters.screenWidth, parameters.screenHeight);
}

function create_shader(src, type) {
    var shader = gl.createShader(type);

    gl.shaderSource(shader, src);
    gl.compileShader(shader);

    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {

        var error = gl.getShaderInfoLog(shader);

        while ((error.length > 1) && (error.charCodeAt(error.length - 1) < 32)) {
            error = error.substring(0, error.length - 1);
        }

        console.error(error);

        return null;

    }

    return shader;
}

